import { invoke } from "@tauri-apps/api/core";

let todos = [];
let currentFilter = 'all';
let nextId = 1;

async function loadTodos() {
  try {
    const data = await invoke("load_todos");
    if (data) {
      todos = data.todos || [];
      nextId = data.nextId || 1;
    }
  } catch (e) {
    console.log("首次运行，使用空数据");
  }
  render();
}

async function saveTodos() {
  try {
    await invoke("save_todos", { data: { todos, nextId } });
  } catch (e) {
    console.error("保存失败:", e);
  }
}

async function addTodo() {
  const input = document.getElementById('todo-input');
  const prioritySelect = document.getElementById('priority-select');
  const text = input.value.trim();
  if (!text) return;

  const todo = {
    id: nextId++,
    text: text,
    completed: false,
    priority: prioritySelect.value,
    createdAt: new Date().toLocaleString('zh-CN', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
  };

  todos.unshift(todo);
  input.value = '';
  await saveTodos();
  render();
}

async function toggleTodo(id) {
  const todo = todos.find(t => t.id === id);
  if (todo) {
    todo.completed = !todo.completed;
    await saveTodos();
    render();
  }
}

async function deleteTodo(id) {
  todos = todos.filter(t => t.id !== id);
  await saveTodos();
  render();
}

async function clearCompleted() {
  todos = todos.filter(t => !t.completed);
  await saveTodos();
  render();
}

function setFilter(filter) {
  currentFilter = filter;
  document.querySelectorAll('.filter-tab').forEach(tab => {
    tab.classList.remove('active');
    if (tab.dataset.filter === filter) {
      tab.classList.add('active');
    }
  });
  render();
}

function getPriorityLabel(p) {
  const map = { high: '高', medium: '中', low: '低' };
  return map[p] || '中';
}

function getPriorityClass(p) {
  return 'priority-' + (p || 'medium');
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function render() {
  const listEl = document.getElementById('todo-list');
  const total = todos.length;
  const completed = todos.filter(t => t.completed).length;
  const pending = total - completed;

  document.getElementById('stat-total').textContent = `总计: ${total}`;
  document.getElementById('stat-done').textContent = `已完成: ${completed}`;
  document.getElementById('stat-pending').textContent = `待办: ${pending}`;

  const progress = total > 0 ? (completed / total * 100) : 0;
  document.getElementById('progress-fill').style.width = progress + '%';
  document.getElementById('footer-info').textContent = `${total} 个任务`;

  let filtered = todos;
  if (currentFilter === 'active') filtered = todos.filter(t => !t.completed);
  if (currentFilter === 'completed') filtered = todos.filter(t => t.completed);

  if (filtered.length === 0) {
    const msg = currentFilter === 'all' ? '还没有任务，添加一个吧！' :
                currentFilter === 'active' ? '太棒了！所有任务都已完成 🎉' :
                '还没有已完成的任务';
    listEl.innerHTML = `
      <div class="empty-state">
        <div class="icon">${currentFilter === 'active' ? '🎉' : '📝'}</div>
        <p>${msg}</p>
      </div>
    `;
    return;
  }

  listEl.innerHTML = filtered.map(todo => `
    <div class="todo-item ${todo.completed ? 'completed' : ''}">
      <div class="checkbox ${todo.completed ? 'checked' : ''}" onclick="window.toggleTodo(${todo.id})"></div>
      <div class="todo-content">
        <div class="todo-text">${escapeHtml(todo.text)}</div>
        <div class="todo-meta">
          <span class="priority-badge ${getPriorityClass(todo.priority)}">${getPriorityLabel(todo.priority)}优先级</span>
          <span class="todo-time">${todo.createdAt}</span>
        </div>
      </div>
      <button class="btn-delete" onclick="window.deleteTodo(${todo.id})" title="删除">🗑</button>
    </div>
  `).join('');
}

window.toggleTodo = toggleTodo;
window.deleteTodo = deleteTodo;
window.setFilter = setFilter;
window.addTodo = addTodo;
window.clearCompleted = clearCompleted;

document.addEventListener('DOMContentLoaded', () => {
  loadTodos();
  document.getElementById('todo-input').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') addTodo();
  });
});
